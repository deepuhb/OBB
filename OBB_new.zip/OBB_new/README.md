# OBB_new – YOLO v11‑style Oriented Box and Keypoint Detection

This repository implements a high‑performance detector for oriented bounding
boxes (OBBs) and a single keypoint per object, following many of the design
choices found in the Ultralytics YOLO v11 family.  The model combines a
deep **CSPDarknet** backbone, a bidirectional **PAN‑FPN** neck, and a
YOLO‑style detection head with **distributional focal loss (DFL)** for width
and height regression, a **single logit angle** to predict orientation,
objectness, classification and an optional keypoint branch.  During
training each ground‑truth object is assigned to the appropriate pyramid
level based on its size and to a neighbourhood of grid cells around its
centre.  The model uses **mmcv** operators for computing rotated IoU and
non‑maximum suppression and supports CPU, single‑GPU and multi‑GPU
training via PyTorch's distributed data parallelism.

## Features

* **Advanced backbone** – A large CSPDarknet architecture with multi‑scale
  feature extraction and Cross‑Stage Partial (CSP) connections.  The
  backbone outputs three stages (P3, P4, P5) at strides 8, 16 and 32.
* **PAN‑FPN neck** – A lightweight yet expressive path aggregation network
  fuses features in a top‑down and bottom‑up manner to enrich lower layers
  with high‑level context.
* **Distributional bounding box regression** – Width and height are
  predicted as discrete distributions over `reg_max+1` bins; the expected
  value recovers continuous sizes.  A single logit predicts rotation,
  mapped to `[‑π/2, π/2)` and canonicalised to ensure `w ≥ h`.
* **Objectness and classification** – YOLO‑style objectness with a bias
  initialised to encourage low scores at the start of training, plus
  multi‑class classification using focal loss.
* **Keypoint regression** – Each box carries a single keypoint predicted
  as offsets relative to the box centre.  A simple MLP branch regresses
  the keypoint for each anchor.
* **mmcv integration** – Rotated IoU and rotated NMS are computed via
  `mmcv.ops.box_iou_rotated` and `mmcv.ops.nms_rotated` respectively.
* **Multi‑GPU training** – The training script uses
  `torch.nn.parallel.DistributedDataParallel` with
  `find_unused_parameters=True` and supports mixed precision via
  `torch.amp`.  It will run on CPU, a single GPU or multiple GPUs.
* **Augmentation** – Mosaic and HSV augmentation can be enabled via a
  wrapper dataset.  Random horizontal/vertical flips and colour jitter
  further diversify the training data.

## Getting Started

1. **Install dependencies**: You need Python 3.10+, PyTorch 2.x,
   torchvision, mmcv and mmengine.  In addition install the local
   requirements by running

   ```bash
   pip install -r requirements.txt
   ```

2. **Prepare a dataset**: The dataset format follows the YOLO style.  For
   each split (train/val/test) create a file `train.txt` listing image
   paths relative to the dataset root.  For each image there must be a
   corresponding label file under `labels/` with the same stem and
   extension `.txt`.  Each line of a label file contains:

   ```
   cls x1 y1 x2 y2 x3 y3 x4 y4 kx ky
   ```

   where `(x1,y1)…(x4,y4)` are the four corner coordinates of the
   quadrilateral in normalised image coordinates (`[0,1]`) following the
   order top‑left, top‑right, bottom‑right, bottom‑left, and `(kx,ky)` is
   the keypoint coordinate in `[0,1]`.

3. **Training**:

   ```bash
   PYTHONPATH=. torchrun --standalone --nproc_per_node=<num_gpus> \
       OBB_new/scripts/train.py \
       --data <dataset_root> \
       --epochs 300 \
       --batch 32 \
       --img_size 640 \
       --num_classes <nc>
   ```

   See `scripts/train.py --help` for more options.  The training
   automatically evaluates mAP@0.5 every few epochs using rotated IoU and
   NMS.

4. **Inference**: Use `src/models/yolo_obb_pose.py` to load your trained
   model and call `decode_obb_from_pyramids` to obtain oriented boxes,
   scores, labels and keypoints.

## Repository Structure

```
OBB_new/
  README.md            – This file
  src/
    data/
      datasets.py      – Dataset loader with mosaic and transforms
      transforms.py    – Random flips and colour jitter
      mosaic.py        – Mosaic and mixup augmentation
      collate.py       – Custom batch collation
    models/
      backbone/
        cspdarknet.py  – CSPDarknet backbone
      neck/
        pan_fpn.py     – PAN‑FPN neck
      heads/
        obbpose_head.py – Detection head
      losses/
        obb_pose_loss.py – Loss criterion
      yolo_obb_pose.py – Model wrapper combining backbone, neck, head
    engine/
      trainer.py       – Training loop with DDP support
      evaluate.py      – mAP evaluation with rotated IoU
  scripts/
    train.py           – Command‑line training entry
    unit_test.py       – Simple unit tests on a sample dataset
```

We provide a lightweight unit test in `scripts/unit_test.py` that reads
the attached sample image and a dummy label, runs the model in eval mode
and checks output shapes.  This ensures that all components integrate
correctly without requiring full training.  Users can extend this to
their own datasets and metrics.
