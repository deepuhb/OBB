#!/usr/bin/env python
"""Training script for OBB_new.

This script trains the model on a dataset of oriented bounding boxes and
keypoints.  It supports multi‑GPU training via ``torchrun`` and
distributed data parallelism.  Use ``--help`` to see available
arguments.
"""

from __future__ import annotations

import os
import argparse
import torch
import torch.distributed as dist
from torch.utils.data import DataLoader, DistributedSampler

# When executed as a script, assume PYTHONPATH=. so OBB_new is importable.
from OBB_new.src.data.datasets import YoloObbKptDataset  # type: ignore
from OBB_new.src.data.collate import collate_obbdet  # type: ignore
from OBB_new.src.models.yolo_obb_pose import YOLOOBBPOSE  # type: ignore
from OBB_new.src.models.losses.obb_pose_loss import OBBCriterion  # type: ignore
from OBB_new.src.engine.trainer import train  # type: ignore


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train OBB_new model")
    parser.add_argument("--data", type=str, required=True, help="Dataset root directory")
    parser.add_argument("--epochs", type=int, default=100, help="Number of epochs")
    parser.add_argument("--batch", type=int, default=16, help="Batch size per GPU")
    parser.add_argument("--img_size", type=int, default=640, help="Input image size (square)")
    parser.add_argument("--num_classes", type=int, default=1, help="Number of object classes")
    parser.add_argument("--lr", type=float, default=0.001, help="Initial learning rate")
    parser.add_argument("--reg_max", type=int, default=8, help="DFL maximum bin index")
    parser.add_argument("--base_channels", type=int, default=64, help="Base channels for backbone")
    parser.add_argument("--base_depth", type=int, default=3, help="Base depth for CSP stages")
    parser.add_argument("--neighbor_range", type=int, default=1, help="Radius for positive assignment")
    parser.add_argument("--lambda_iou", type=float, default=0.0, help="Weight for IoU penalty term")
    parser.add_argument("--workers", type=int, default=8, help="Number of DataLoader workers")
    parser.add_argument("--no_aug", action="store_true", help="Disable mosaic augmentation")
    parser.add_argument("--device", type=str, default="cuda", help="Device for training (cpu or cuda)")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    # determine if distributed
    rank = int(os.environ.get("RANK", "0"))
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    distributed = world_size > 1
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    if distributed:
        dist.init_process_group(backend="nccl" if device.type == "cuda" else "gloo")
    # build datasets
    train_dataset = YoloObbKptDataset(root=args.data, split="train", img_size=args.img_size, mosaic=not args.no_aug)
    val_dataset = None
    val_list = os.path.join(args.data, "val.txt")
    if os.path.isfile(val_list):
        val_dataset = YoloObbKptDataset(root=args.data, split="val", img_size=args.img_size, mosaic=False)
    # samplers
    if distributed:
        train_sampler = DistributedSampler(train_dataset, shuffle=True)
        val_sampler = DistributedSampler(val_dataset, shuffle=False) if val_dataset is not None else None
    else:
        train_sampler = None
        val_sampler = None
    # dataloaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch,
        shuffle=(train_sampler is None),
        sampler=train_sampler,
        num_workers=args.workers,
        collate_fn=collate_obbdet,
        pin_memory=True,
        drop_last=False,
    )
    val_loader = None
    if val_dataset is not None:
        val_loader = DataLoader(
            val_dataset,
            batch_size=args.batch,
            shuffle=False,
            sampler=val_sampler,
            num_workers=args.workers,
            collate_fn=collate_obbdet,
            pin_memory=True,
            drop_last=False,
        )
    # build model
    model = YOLOOBBPOSE(
        num_classes=args.num_classes,
        base_channels=args.base_channels,
        base_depth=args.base_depth,
        reg_max=args.reg_max,
    )
    model.to(device)
    # wrap DDP
    if distributed:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[int(os.environ.get("LOCAL_RANK", "0"))], find_unused_parameters=True)
    # criterion
    criterion = OBBCriterion(
        num_classes=args.num_classes,
        strides=(8, 16, 32),
        level_boundaries=(32.0, 64.0),
        neighbor_range=args.neighbor_range,
        lambda_box=5.0,
        lambda_obj=1.0,
        lambda_cls=0.5,
        lambda_ang=0.5,
        lambda_kpt=2.0,
        lambda_iou=args.lambda_iou,
    )
    # optimiser
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)
    # mixed precision
    scaler = torch.cuda.amp.GradScaler(enabled=(device.type == "cuda"))
    # train
    train(
        model=model,
        criterion=criterion,
        train_loader=train_loader,
        val_loader=val_loader,
        optimiser=optimizer,
        device=device,
        epochs=args.epochs,
        eval_interval=5,
        scaler=scaler,
        max_norm=10.0,
    )
    # cleanup
    if distributed:
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
