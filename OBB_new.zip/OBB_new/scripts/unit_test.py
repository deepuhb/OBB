#!/usr/bin/env python
"""Simple unit test for OBB_new.

This script creates a temporary dataset from the attached sample image
and label, instantiates the model and runs a forward pass and decode.
It then computes the mAP@0.5 on the sample dataset.  The test does
not require GPU and runs quickly.
"""

import os
import shutil
import torch

from OBB_new.src.data.datasets import YoloObbKptDataset  # type: ignore
from OBB_new.src.data.collate import collate_obbdet  # type: ignore
from OBB_new.src.models.yolo_obb_pose import YOLOOBBPOSE  # type: ignore
from OBB_new.src.models.losses.obb_pose_loss import OBBCriterion  # type: ignore
from OBB_new.src.engine.evaluate import evaluate  # type: ignore

def main() -> None:
    # prepare temporary dataset directory
    tmp_root = "tmp_sample"
    os.makedirs(os.path.join(tmp_root, "images"), exist_ok=True)
    os.makedirs(os.path.join(tmp_root, "labels"), exist_ok=True)
    # copy sample image and label from repository root
    src_img = os.path.join(os.path.dirname(__file__), "..", "..", "image_20250512_151906_591_0_0.png")
    src_lbl = os.path.join(os.path.dirname(__file__), "..", "..", "image_20250512_151906_591_0_0.txt")
    dst_img = os.path.join(tmp_root, "images", "image_20250512_151906_591_0_0.png")
    dst_lbl = os.path.join(tmp_root, "labels", "image_20250512_151906_591_0_0.txt")
    shutil.copy(src_img, dst_img)
    shutil.copy(src_lbl, dst_lbl)
    # create train and val lists
    with open(os.path.join(tmp_root, "train.txt"), "w") as f:
        f.write("image_20250512_151906_591_0_0.png\n")
    with open(os.path.join(tmp_root, "val.txt"), "w") as f:
        f.write("image_20250512_151906_591_0_0.png\n")
    # dataset
    dataset = YoloObbKptDataset(root=tmp_root, split="train", img_size=640, mosaic=False)
    img, tgt = dataset[0]
    print(f"Sample image shape: {img.shape}")
    print(f"Sample targets: {tgt}")
    # model
    model = YOLOOBBPOSE(num_classes=1, base_channels=32, base_depth=1, reg_max=8)
    model.eval()
    # forward and decode
    with torch.no_grad():
        det_maps, kpt_maps = model(img.unsqueeze(0))
        preds = model.head.decode_obb_from_pyramids(det_maps, kpt_maps, img.unsqueeze(0), score_thr=0.01, iou_thres=0.5, max_det=50)
    print(f"Decoded predictions: {preds}")
    # evaluation
    loader = torch.utils.data.DataLoader(dataset, batch_size=1, collate_fn=collate_obbdet)
    ap = evaluate(model, loader, iou_threshold=0.5, score_threshold=0.01, max_det=50)
    print(f"mAP50 on sample: {ap['mAP']:.4f}")

if __name__ == "__main__":
    main()
