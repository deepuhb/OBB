"""Root package for OBB_new.

This package exposes data loaders, model components and training utilities
for oriented bounding box and keypoint detection.
"""

__all__ = []