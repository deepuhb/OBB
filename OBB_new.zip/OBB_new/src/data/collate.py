"""Custom batch collation for OBB and keypoint detection.

The collate function builds mini‑batches out of individual samples returned
by the dataset.  Each sample consists of an image tensor and a target
dictionary containing oriented boxes, class labels, keypoints and
keypoint offsets.  The images are stacked along the batch dimension while
targets remain as a list of dictionaries.  This approach allows
variable‑sized targets per image.
"""

from __future__ import annotations

from typing import List, Tuple, Dict, Any
import torch


def collate_obbdet(batch: List[Tuple[torch.Tensor, Dict[str, torch.Tensor]]]) -> Tuple[torch.Tensor, List[Dict[str, torch.Tensor]]]:
    """Stack images and collect targets into a list.

    Args:
        batch: list of tuples (image, targets) produced by the dataset.
    Returns:
        images: tensor of shape (B, 3, H, W).
        targets: list of length B with target dicts.
    """
    imgs: List[torch.Tensor] = []
    targets_out: List[Dict[str, torch.Tensor]] = []
    for img, tgt in batch:
        imgs.append(img)
        targets_out.append(tgt)
    images = torch.stack(imgs, dim=0)
    return images, targets_out


__all__ = ["collate_obbdet"]
