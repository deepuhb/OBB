"""Data augmentation and preprocessing transforms for oriented box detection.

This module defines a set of simple image and annotation transformations that
are commonly used for object detection.  They operate on a tuple
``(image, targets)`` where ``image`` is a ``PIL.Image`` or tensor and
``targets`` is a dictionary containing at least the keys ``boxes``
(``Tensor[N, 5]``), ``labels`` (``Tensor[N]``) and optionally
``keypoints`` (``Tensor[N, 2]``).

The transforms include random horizontal and vertical flips and colour jitter
(HSV jitter).  They are designed to be composable using the ``Compose``
class.  All transforms preserve the orientation of the bounding boxes
according to the LE‑90 convention (w ≥ h, angle ∈ [‑π/2, π/2)).
"""

from __future__ import annotations

import random
import torch
import numpy as np
from typing import Tuple, Dict, Any, List
from PIL import Image


def _rotate_points(
    pts: torch.Tensor, cx: torch.Tensor, cy: torch.Tensor, ang: torch.Tensor
) -> torch.Tensor:
    """Rotate points ``pts`` around centre (cx,cy) by angle ``ang`` (rad).

    Args:
        pts: (..., 2) tensor of points.
        cx, cy: (...,) tensors of centres.
        ang: (...,) tensor of angles in radians.
    Returns:
        rotated_pts: (..., 2) tensor of rotated points.
    """
    # translate to origin
    dx = pts[..., 0] - cx[..., None]
    dy = pts[..., 1] - cy[..., None]
    # rotate
    cos_a = torch.cos(ang[..., None])
    sin_a = torch.sin(ang[..., None])
    rx = dx * cos_a - dy * sin_a
    ry = dx * sin_a + dy * cos_a
    return torch.stack([rx + cx[..., None], ry + cy[..., None]], dim=-1)


class Compose:
    """Composes several transforms together.

    Example::
        transforms = Compose([RandomHorizontalFlip(), RandomVerticalFlip()])
        image, targets = transforms(image, targets)
    """
    def __init__(self, transforms: List[Any]) -> None:
        self.transforms = transforms

    def __call__(self, img: Image.Image, targets: Dict[str, torch.Tensor]) -> Tuple[Image.Image, Dict[str, torch.Tensor]]:
        for t in self.transforms:
            img, targets = t(img, targets)
        return img, targets


class RandomHorizontalFlip:
    """Randomly flip the image horizontally with probability 0.5."""
    def __init__(self, p: float = 0.5) -> None:
        self.p = float(p)

    def __call__(self, img: Image.Image, targets: Dict[str, torch.Tensor]) -> Tuple[Image.Image, Dict[str, torch.Tensor]]:
        if random.random() > self.p:
            return img, targets
        # flip image
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
        W = img.width
        boxes = targets["boxes"].clone()
        # boxes: (cx,cy,w,h,theta)
        cx, cy, w, h, ang = boxes.t()
        # flip centre: x' = W - cx
        cx = W - cx
        # invert angle: angle -> -angle
        ang = -ang
        # keypoints
        if "keypoints" in targets and targets["keypoints"] is not None:
            kp = targets["keypoints"].clone()
            kp[:, 0] = W - kp[:, 0]
            targets["keypoints"] = kp
        targets["boxes"] = torch.stack([cx, cy, w, h, ang], dim=1)
        return img, targets


class RandomVerticalFlip:
    """Randomly flip the image vertically with probability 0.5."""
    def __init__(self, p: float = 0.5) -> None:
        self.p = float(p)

    def __call__(self, img: Image.Image, targets: Dict[str, torch.Tensor]) -> Tuple[Image.Image, Dict[str, torch.Tensor]]:
        if random.random() > self.p:
            return img, targets
        img = img.transpose(Image.FLIP_TOP_BOTTOM)
        H = img.height
        boxes = targets["boxes"].clone()
        cx, cy, w, h, ang = boxes.t()
        cy = H - cy
        ang = -ang
        if "keypoints" in targets and targets["keypoints"] is not None:
            kp = targets["keypoints"].clone()
            kp[:, 1] = H - kp[:, 1]
            targets["keypoints"] = kp
        targets["boxes"] = torch.stack([cx, cy, w, h, ang], dim=1)
        return img, targets


class RandomHSV:
    """Random HSV (hue, saturation, value) jitter.

    Applies a random change to the hue, saturation and brightness of the image.
    The input must be a PIL image.  The jitter strength is controlled by
    ``hgain``, ``sgain`` and ``vgain``.
    """
    def __init__(self, hgain: float = 0.015, sgain: float = 0.7, vgain: float = 0.4) -> None:
        self.hgain = float(hgain)
        self.sgain = float(sgain)
        self.vgain = float(vgain)

    def __call__(self, img: Image.Image, targets: Dict[str, torch.Tensor]) -> Tuple[Image.Image, Dict[str, torch.Tensor]]:
        if not isinstance(img, Image.Image):
            return img, targets
        # convert to HSV
        hsv = np.array(img.convert("HSV"), dtype=np.float32)
        h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
        # random gains
        r = np.random.uniform(-1, 1, size=3) * np.array([self.hgain, self.sgain, self.vgain]) + 1
        h = (h * r[0]) % 360
        s = np.clip(s * r[1], 0, 255)
        v = np.clip(v * r[2], 0, 255)
        hsv = np.stack([h, s, v], axis=-1)
        img = Image.fromarray(hsv.astype(np.uint8), mode="HSV").convert(img.mode)
        return img, targets


__all__ = [
    "Compose",
    "RandomHorizontalFlip",
    "RandomVerticalFlip",
    "RandomHSV",
]
