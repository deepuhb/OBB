"""Mosaic and mixup augmentations for oriented box detection.

This module provides helper functions for creating mosaic images by
combining four images into a larger canvas.  When mosaic is enabled, four
random images (including the current sample) are selected and placed in
quadrants of the output canvas.  Bounding boxes and keypoints are
transformed accordingly.  Mosaic augmentation can significantly improve
model robustness by exposing objects at different scales and positions.

For simplicity this implementation handles only the mosaic case; mixup and
other advanced augmentations can be added as needed.
"""

from __future__ import annotations

import random
import math
from typing import Tuple, List, Dict, Any

import numpy as np
from PIL import Image
import torch


def _resize_and_pad(
    img: Image.Image, target_size: int
) -> Tuple[np.ndarray, float, float, int, int]:
    """Resize and pad an image to a square (target_size×target_size).

    Returns the resized image as an array and the scaling factors and
    paddings applied along x and y.
    """
    w, h = img.size
    scale = target_size / max(h, w)
    new_w, new_h = int(w * scale), int(h * scale)
    img_resized = img.resize((new_w, new_h), Image.BILINEAR)
    canvas = np.full((target_size, target_size, 3), 114, dtype=np.uint8)
    # top‑left corner
    pad_x = (target_size - new_w) // 2
    pad_y = (target_size - new_h) // 2
    canvas[pad_y : pad_y + new_h, pad_x : pad_x + new_w] = np.array(img_resized)
    return canvas, scale, scale, pad_x, pad_y


def mosaic4(
    images: List[Image.Image],
    targets: List[Dict[str, Any]],
    img_size: int,
) -> Tuple[Image.Image, Dict[str, torch.Tensor]]:
    """Create a 2×2 mosaic from four images and their targets.

    Args:
        images: list of four PIL images.
        targets: list of four target dicts corresponding to the images. Each
            target must contain ``boxes`` (Tensor[N, 5]), ``labels`` and
            optionally ``keypoints``.
        img_size: output square size (in pixels).
    Returns:
        mosaic_img: PIL.Image of size (img_size, img_size, 3).
        mosaic_targets: dict with concatenated boxes, labels and keypoints.
    """
    assert len(images) == 4 and len(targets) == 4
    # base canvas filled with grey
    mosaic_img = np.full((img_size * 2, img_size * 2, 3), 114, dtype=np.uint8)
    mosaic_boxes: List[torch.Tensor] = []
    mosaic_labels: List[torch.Tensor] = []
    mosaic_kpts: List[torch.Tensor] = []
    # mosaic centre coordinates (xc,yc) relative to large canvas
    xc = int(random.uniform(img_size // 2, img_size * 3 // 2))
    yc = int(random.uniform(img_size // 2, img_size * 3 // 2))
    # positions for 4 quadrants: top‑left, top‑right, bottom‑left, bottom‑right
    positions = [
        (0, 0),
        (0, 1),
        (1, 0),
        (1, 1),
    ]
    for i, (img, tgt) in enumerate(zip(images, targets)):
        # resize image to target size without padding; compute scaling
        img_np = np.array(img)
        h, w = img_np.shape[:2]
        # random scale between 0.5 and 1.5
        scale = random.uniform(0.5, 1.5)
        new_w, new_h = int(w * scale), int(h * scale)
        img_res = Image.fromarray(img_np).resize((new_w, new_h), Image.BILINEAR)
        img_res_np = np.array(img_res)
        # determine placement
        pos_y, pos_x = positions[i]
        # compute coordinates of mosaic slice
        if pos_y == 0:
            y1 = max(yc - new_h, 0)
            y2 = yc
            ys1 = new_h - (y2 - y1)
            ys2 = new_h
        else:
            y1 = yc
            y2 = min(yc + new_h, img_size * 2)
            ys1 = 0
            ys2 = y2 - y1
        if pos_x == 0:
            x1 = max(xc - new_w, 0)
            x2 = xc
            xs1 = new_w - (x2 - x1)
            xs2 = new_w
        else:
            x1 = xc
            x2 = min(xc + new_w, img_size * 2)
            xs1 = 0
            xs2 = x2 - x1
        # paste image patch
        mosaic_img[y1:y2, x1:x2] = img_res_np[ys1:ys2, xs1:xs2]
        # scale boxes and keypoints
        boxes = tgt["boxes"].clone()  # (N,5) cx,cy,w,h,theta in image pixels
        labels = tgt["labels"].clone()
        kpts = tgt.get("keypoints", None)
        # compute scale from original to resized
        # boxes are in pixels of original image; multiply by scale
        boxes[:, 0:4] *= torch.tensor([scale, scale, scale, scale], dtype=boxes.dtype)
        # keypoints
        if kpts is not None:
            kpts = kpts.clone() * torch.tensor([scale, scale], dtype=kpts.dtype)
        # shift boxes/keypoints by mosaic offset
        # compute origin shift (x_offset,y_offset)
        dx = x1 - xs1
        dy = y1 - ys1
        boxes[:, 0] += dx
        boxes[:, 1] += dy
        if kpts is not None:
            kpts[:, 0] += dx
            kpts[:, 1] += dy
        # clip boxes to mosaic boundaries
        # ensure boxes lie within [0, 2*img_size)
        boxes[:, 0] = boxes[:, 0].clamp(0, img_size * 2)
        boxes[:, 1] = boxes[:, 1].clamp(0, img_size * 2)
        boxes[:, 2] = boxes[:, 2].clamp(min=2.0, max=img_size * 2)
        boxes[:, 3] = boxes[:, 3].clamp(min=2.0, max=img_size * 2)
        mosaic_boxes.append(boxes)
        mosaic_labels.append(labels)
        mosaic_kpts.append(kpts)
    # concatenate targets
    if mosaic_boxes:
        mosaic_boxes = torch.cat(mosaic_boxes, dim=0)
        mosaic_labels = torch.cat(mosaic_labels, dim=0)
        if mosaic_kpts[0] is not None:
            mosaic_kpts_cat = torch.cat([k for k in mosaic_kpts if k is not None], dim=0)
        else:
            mosaic_kpts_cat = None
    else:
        mosaic_boxes = torch.zeros((0, 5), dtype=torch.float32)
        mosaic_labels = torch.zeros((0,), dtype=torch.int64)
        mosaic_kpts_cat = None
    # crop to final img_size × img_size from the centre of mosaic_img
    x_start = (2 * img_size - img_size) // 2
    y_start = (2 * img_size - img_size) // 2
    mosaic_img = mosaic_img[y_start : y_start + img_size, x_start : x_start + img_size]
    # adjust boxes and keypoints for final crop
    mosaic_boxes[:, 0] -= x_start
    mosaic_boxes[:, 1] -= y_start
    if mosaic_kpts_cat is not None:
        mosaic_kpts_cat[:, 0] -= x_start
        mosaic_kpts_cat[:, 1] -= y_start
    # remove boxes that are too small or outside crop
    # filter boxes with zero area
    keep = (mosaic_boxes[:, 2] > 4.0) & (mosaic_boxes[:, 3] > 4.0)
    mosaic_boxes = mosaic_boxes[keep]
    mosaic_labels = mosaic_labels[keep]
    if mosaic_kpts_cat is not None:
        mosaic_kpts_cat = mosaic_kpts_cat[keep]
    # cast back to PIL
    mosaic_img_pil = Image.fromarray(mosaic_img.astype(np.uint8))
    res_targets: Dict[str, torch.Tensor] = {
        "boxes": mosaic_boxes,
        "labels": mosaic_labels,
    }
    if mosaic_kpts_cat is not None:
        res_targets["keypoints"] = mosaic_kpts_cat
    return mosaic_img_pil, res_targets


__all__ = ["mosaic4"]
