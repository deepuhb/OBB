"""Dataset loader for oriented bounding box (OBB) and keypoint detection.

This module defines a dataset class that reads images and labels from a
YOLO‑style annotation format and produces samples suitable for training
YOLO‑v11‑style detectors.  Each label line contains the object class,
four corner coordinates of a quadrilateral and a single keypoint.
The loader converts these quadrilaterals into oriented bounding boxes
(cx, cy, w, h, angle) and computes keypoint offsets relative to each box.

Optional mosaic augmentation is implemented via the ``mosaic`` argument.
When enabled, a random mosaic of four images is generated on‑the‑fly.
Transforms may be applied afterwards to each sample.
"""

from __future__ import annotations

import os
import random
import math
from typing import List, Dict, Any, Tuple, Optional

import torch
from torch.utils.data import Dataset
import numpy as np
from PIL import Image
import cv2

from .transforms import Compose, RandomHorizontalFlip, RandomVerticalFlip, RandomHSV
from .mosaic import mosaic4


def _quad_to_obb_radians(quads: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Convert quadrilaterals to oriented bounding boxes in radians.

    Args:
        quads: array of shape (N, 8) containing 4 points per box in the
            order x1,y1,x2,y2,x3,y3,x4,y4 (pixels).
    Returns:
        boxes: array of shape (N, 5) with (cx, cy, w, h, angle_rad).
        valid: boolean mask indicating boxes with positive area.
    """
    N = quads.shape[0]
    boxes = np.zeros((N, 5), dtype=np.float32)
    valid = np.ones((N,), dtype=bool)
    for i in range(N):
        pts = quads[i].reshape(4, 2).astype(np.float32)
        # compute minimum area rectangle
        rect = cv2.minAreaRect(pts)
        (cx, cy), (w, h), angle_deg = rect
        # cv2 returns angle in range [-90,0) such that width is longer side
        # convert to radians
        angle = math.radians(angle_deg)
        # ensure width ≥ height; if not, swap and adjust angle by 90 degrees
        if w < h:
            w, h = h, w
            angle += math.pi / 2.0
        # wrap angle to [-pi/2, pi/2)
        angle = (angle + math.pi / 2.0) % math.pi - math.pi / 2.0
        boxes[i] = (cx, cy, w, h, angle)
        if w <= 0 or h <= 0:
            valid[i] = False
    return boxes, valid


class YoloObbKptDataset(Dataset):
    """Dataset of images annotated with oriented bounding boxes and keypoints.

    Each annotation line in the label file must have the format::

        cls x1 y1 x2 y2 x3 y3 x4 y4 kx ky

    where coordinates are floating‑point numbers in the range [0,1] and
    correspond to the image width/height.  The four points describe the
    quadrilateral in order (top‑left, top‑right, bottom‑right, bottom‑left)
    and (kx,ky) denotes the keypoint.  During loading, quadrilaterals
    are converted to oriented bounding boxes using OpenCV's
    ``minAreaRect``.  Keypoints are converted to offsets relative to the
    oriented bounding box's local frame and stored in ``kpt_offsets``.

    Args:
        root: root directory of the dataset.  Must contain a subdirectory
            ``images`` with image files and a subdirectory ``labels`` with
            corresponding ``*.txt`` files.  Also must contain ``train.txt``
            or ``val.txt`` listing relative image paths for the given split.
        split: which split to load (``"train"`` or ``"val"``).
        img_size: size to which images are resized and padded (square).
        mosaic: whether to apply mosaic augmentation during training.
        transforms: optional callable applied to each sample after
            loading/mosaic.  Default includes random HSV and flips.
    """

    def __init__(
        self,
        root: str,
        split: str = "train",
        img_size: int = 640,
        mosaic: bool = False,
        transforms: Optional[Any] = None,
    ) -> None:
        super().__init__()
        self.root = root
        self.split = split
        self.img_size = int(img_size)
        self.mosaic = bool(mosaic)
        # list of image file paths
        list_path = os.path.join(root, f"{split}.txt")
        assert os.path.isfile(list_path), f"File not found: {list_path}"
        with open(list_path, "r") as f:
            self.img_files = [os.path.join(root, "images", x.strip()) for x in f.readlines() if x.strip()]
        # default transforms
        if transforms is None:
            self.transforms = Compose([
                RandomHSV(),
                RandomHorizontalFlip(),
                RandomVerticalFlip(),
            ])
        else:
            self.transforms = transforms

    def __len__(self) -> int:
        return len(self.img_files)

    def __getitem__(self, index: int) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        # decide whether to apply mosaic
        if self.mosaic and self.split == "train" and random.random() < 0.5:
            # sample 4 images (including current)
            indices = [index] + random.choices(range(len(self)), k=3)
            imgs = []
            tgts = []
            for idx in indices:
                img_path = self.img_files[idx]
                img = Image.open(img_path).convert("RGB")
                w, h = img.size
                label_path = os.path.join(self.root, "labels", os.path.basename(img_path).replace(".jpg", ".txt").replace(".png", ".txt"))
                if not os.path.isfile(label_path):
                    bboxes = torch.zeros((0, 5), dtype=torch.float32)
                    labels = torch.zeros((0,), dtype=torch.int64)
                    kpts = None
                else:
                    with open(label_path, "r") as f:
                        lines = [x.strip() for x in f.readlines() if x.strip()]
                    num = len(lines)
                    quads = np.zeros((num, 8), dtype=np.float32)
                    cls_ids = np.zeros((num,), dtype=np.int64)
                    keypoints = np.zeros((num, 2), dtype=np.float32)
                    for j, line in enumerate(lines):
                        parts = line.split()
                        cls_ids[j] = int(float(parts[0]))
                        coords = [float(p) for p in parts[1:]]
                        quads[j] = coords[:8] * np.array([w, h] * 4, dtype=np.float32)
                        keypoints[j] = coords[8:10] * np.array([w, h], dtype=np.float32)
                    bboxes, valid = _quad_to_obb_radians(quads)
                    bboxes = bboxes[valid]
                    cls_ids = cls_ids[valid]
                    keypoints = keypoints[valid]
                    bboxes = torch.from_numpy(bboxes)
                    labels = torch.from_numpy(cls_ids)
                    kpts = torch.from_numpy(keypoints)
                imgs.append(img)
                tgts.append({"boxes": bboxes, "labels": labels, "keypoints": kpts})
            mosaic_img, mosaic_targets = mosaic4(imgs, tgts, self.img_size)
            img = mosaic_img
            targets = mosaic_targets
        else:
            # load single image
            img_path = self.img_files[index]
            img = Image.open(img_path).convert("RGB")
            w, h = img.size
            label_path = os.path.join(self.root, "labels", os.path.basename(img_path).replace(".jpg", ".txt").replace(".png", ".txt"))
            if not os.path.isfile(label_path):
                bboxes = torch.zeros((0, 5), dtype=torch.float32)
                labels = torch.zeros((0,), dtype=torch.int64)
                kpts = None
            else:
                with open(label_path, "r") as f:
                    lines = [x.strip() for x in f.readlines() if x.strip()]
                num = len(lines)
                quads = np.zeros((num, 8), dtype=np.float32)
                cls_ids = np.zeros((num,), dtype=np.int64)
                keypoints = np.zeros((num, 2), dtype=np.float32)
                for j, line in enumerate(lines):
                    parts = line.split()
                    cls_ids[j] = int(float(parts[0]))
                    coords = [float(p) for p in parts[1:]]
                    quads[j] = coords[:8] * np.array([w, h] * 4, dtype=np.float32)
                    keypoints[j] = coords[8:10] * np.array([w, h], dtype=np.float32)
                bboxes, valid = _quad_to_obb_radians(quads)
                bboxes = bboxes[valid]
                cls_ids = cls_ids[valid]
                keypoints = keypoints[valid]
                bboxes = torch.from_numpy(bboxes)
                labels = torch.from_numpy(cls_ids)
                kpts = torch.from_numpy(keypoints)
            targets = {"boxes": bboxes, "labels": labels}
            if kpts is not None:
                targets["keypoints"] = kpts
        # apply transforms (on PIL)
        img, targets = self.transforms(img, targets)
        # ensure torch tensor image of shape (3,H,W)
        img = torch.from_numpy(np.array(img, dtype=np.float32)).permute(2, 0, 1)
        # normalise to [0,1]
        img /= 255.0
        # convert boxes and keypoints to float tensors
        boxes = targets.get("boxes", torch.zeros((0, 5), dtype=torch.float32))
        labels = targets.get("labels", torch.zeros((0,), dtype=torch.int64))
        keypoints = targets.get("keypoints", None)
        # compute keypoint offsets relative to oriented bounding boxes
        kpt_offsets = None
        if keypoints is not None and len(boxes) > 0:
            # compute offsets per box
            kpts = keypoints
            cx = boxes[:, 0]
            cy = boxes[:, 1]
            w_ = boxes[:, 2]
            h_ = boxes[:, 3]
            ang = boxes[:, 4]
            dx = kpts[:, 0] - cx
            dy = kpts[:, 1] - cy
            # rotate offsets by negative angle to align with box orientation
            cos_a = torch.cos(-ang)
            sin_a = torch.sin(-ang)
            rot_x = dx * cos_a - dy * sin_a
            rot_y = dx * sin_a + dy * cos_a
            u = rot_x / (w_ + 1e-6)
            v = rot_y / (h_ + 1e-6)
            kpt_offsets = torch.stack([u, v], dim=1)
        # pack targets
        out_targets: Dict[str, torch.Tensor] = {
            "boxes": boxes.to(torch.float32),
            "labels": labels.to(torch.int64),
        }
        if keypoints is not None:
            out_targets["keypoints"] = keypoints.to(torch.float32)
        if kpt_offsets is not None:
            out_targets["kpt_offsets"] = kpt_offsets.to(torch.float32)
        return img, out_targets


__all__ = ["YoloObbKptDataset"]
