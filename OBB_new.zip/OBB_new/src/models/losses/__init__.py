"""Loss functions for OBB_new."""

from .obb_pose_loss import OBBCriterion  # noqa

__all__ = ["OBBCriterion"]