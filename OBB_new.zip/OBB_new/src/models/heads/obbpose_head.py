"""YOLO‑style detection head for oriented boxes and single keypoints.

This module defines the detection head used in the OBB_new model.  Each
feature map level produces a tensor with channels ordered as::

    [ tx, ty,        – offsets relative to cell centre
      dfl_w[0..M],  – DFL logits for log‑width (M+1 bins)
      dfl_h[0..M],  – DFL logits for log‑height (M+1 bins)
      ang_logit,    – single logit for angle (mapped to [‑π/2,π/2])
      obj,          – objectness logit
      cls0..cls{nc‑1} – class logits ]

In addition, a tiny keypoint head predicts the keypoint offsets relative to
the oriented box centre.  The keypoint offsets ``(u,v)`` are stored in
``kpt_maps`` in channels 0 and 1.  During decoding, the offsets are
transformed into global coordinates by applying the predicted rotation
and scaling by the width and height of the bounding box.
"""

from __future__ import annotations

from typing import List, Tuple, Dict, Optional, Any
import math
import torch
import torch.nn as nn


class OBBPoseHead(nn.Module):
    """Detection head producing oriented boxes and keypoints.

    Args:
        ch: tuple with channels of the three input feature maps (P3,P4,P5).
        num_classes: number of object classes.
        reg_max: maximum discrete index for DFL (bin count = reg_max + 1).
    """

    def __init__(self, ch: Tuple[int, int, int], num_classes: int, reg_max: int = 8) -> None:
        super().__init__()
        self.num_classes = int(num_classes)
        self.reg_max = int(reg_max)
        self.nbins = self.reg_max + 1
        # precompute bins for DFL expected value
        self.register_buffer(
            "dfl_bins",
            torch.arange(self.nbins, dtype=torch.float32).view(1, self.nbins, 1, 1),
            persistent=False,
        )
        c3, c4, c5 = [int(x) for x in ch]
        # detection output channels: tx,ty, dflw(M), dflh(M), angle, obj, classes
        det_out = 2 + 2 * self.nbins + 1 + 1 + self.num_classes
        # keypoint output channels: kpx,kpy (two offsets)
        kpt_out = 2
        # heads per level
        self.det3 = nn.Sequential(
            nn.Conv2d(c3, c3, 3, 1, 1),
            nn.BatchNorm2d(c3),
            nn.SiLU(),
            nn.Conv2d(c3, det_out, 1, 1, 0),
        )
        self.det4 = nn.Sequential(
            nn.Conv2d(c4, c4, 3, 1, 1),
            nn.BatchNorm2d(c4),
            nn.SiLU(),
            nn.Conv2d(c4, det_out, 1, 1, 0),
        )
        self.det5 = nn.Sequential(
            nn.Conv2d(c5, c5, 3, 1, 1),
            nn.BatchNorm2d(c5),
            nn.SiLU(),
            nn.Conv2d(c5, det_out, 1, 1, 0),
        )
        # keypoint heads
        self.kp3 = nn.Sequential(
            nn.Conv2d(c3, c3, 3, 1, 1),
            nn.BatchNorm2d(c3),
            nn.SiLU(),
            nn.Conv2d(c3, kpt_out, 1, 1, 0),
        )
        self.kp4 = nn.Sequential(
            nn.Conv2d(c4, c4, 3, 1, 1),
            nn.BatchNorm2d(c4),
            nn.SiLU(),
            nn.Conv2d(c4, kpt_out, 1, 1, 0),
        )
        self.kp5 = nn.Sequential(
            nn.Conv2d(c5, c5, 3, 1, 1),
            nn.BatchNorm2d(c5),
            nn.SiLU(),
            nn.Conv2d(c5, kpt_out, 1, 1, 0),
        )
        # grid cache
        self._grid_cache: Dict[Tuple[torch.device, int, int], Tuple[torch.Tensor, torch.Tensor]] = {}
        self._assert_once = False
        # initialise biases
        self._init_bias(self.det3)
        self._init_bias(self.det4)
        self._init_bias(self.det5)

    def _init_bias(self, mod: nn.Sequential) -> None:
        final = mod[-1]
        assert isinstance(final, nn.Conv2d)
        with torch.no_grad():
            b = final.bias
            if b is None or b.numel() == 0:
                final.bias = nn.Parameter(torch.zeros(final.out_channels))
                b = final.bias
            b.zero_()
            # objectness index in channel order
            obj_idx = 2 + 2 * self.nbins + 1
            if b.numel() > obj_idx:
                b[obj_idx] = -3.0

    def forward(self, feats: List[torch.Tensor]) -> Tuple[List[torch.Tensor], List[torch.Tensor]]:
        assert len(feats) == 3, "OBBPoseHead expects 3 feature maps"
        p3, p4, p5 = feats
        det_maps = [self.det3(p3), self.det4(p4), self.det5(p5)]
        kpt_maps = [self.kp3(p3), self.kp4(p4), self.kp5(p5)]
        if not self._assert_once:
            expected = 2 + 2 * self.nbins + 1 + 1 + self.num_classes
            for i in range(3):
                C = det_maps[i].shape[1]
                assert C == expected, (
                    f"det_maps[{i}] channels {C} != expected {expected}"
                )
            self._assert_once = True
        return det_maps, kpt_maps

    @staticmethod
    def _le90(w: torch.Tensor, h: torch.Tensor, ang: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        swap = w < h
        w2 = torch.where(swap, h, w)
        h2 = torch.where(swap, w, h)
        ang2 = torch.where(swap, ang + math.pi / 2.0, ang)
        ang2 = torch.remainder(ang2 + math.pi / 2.0, math.pi) - math.pi / 2.0
        return w2, h2, ang2

    def _ev_from_dfl(self, logits: torch.Tensor) -> torch.Tensor:
        probs = torch.softmax(logits, dim=1)
        bins = self.dfl_bins.to(device=logits.device, dtype=logits.dtype, non_blocking=True)
        return (probs * bins).sum(dim=1, keepdim=True)

    @torch.no_grad()
    def decode_obb_from_pyramids(
        self,
        det_maps: List[torch.Tensor],
        kpt_maps: List[torch.Tensor],
        imgs: torch.Tensor,
        *,
        strides: Tuple[int, int, int] = (8, 16, 32),
        score_thr: float = 0.01,
        iou_thres: float = 0.5,
        max_det: int = 300,
        use_nms: bool = True,
        multi_label: bool = False,
    ) -> List[Dict[str, torch.Tensor]]:
        """Decode detection maps into oriented boxes, scores, labels and keypoints.

        Args:
            det_maps: list of detection maps [(B,C,H,W)*3].
            kpt_maps: list of keypoint maps [(B,2,H,W)*3].
            imgs: input images tensor (B,3,H,W).  Only used for device.
            strides: strides for each level.
            score_thr: confidence threshold.
            iou_thres: IoU threshold for NMS.
            max_det: maximum detections per image after NMS.
            use_nms: whether to apply NMS.
            multi_label: if True, allow multi‑class predictions per box.
        Returns:
            List of dictionaries per image with keys: ``boxes`` (Tensor[M,5]),
            ``scores`` (Tensor[M]), ``labels`` (Tensor[M]), ``keypoints`` (Tensor[M,2]).
        """
        device = det_maps[0].device
        bs = det_maps[0].shape[0]
        results: List[Dict[str, torch.Tensor]] = []
        for b in range(bs):
            boxes_l: List[torch.Tensor] = []
            scores_l: List[torch.Tensor] = []
            labels_l: List[torch.Tensor] = []
            kpts_l: List[torch.Tensor] = []
            # process each level
            for lvl, stride in enumerate(strides):
                dm = det_maps[lvl][b]  # (C,H,W)
                km = kpt_maps[lvl][b]  # (2,H,W)
                C, H, W = dm.shape
                # split channels
                idx = 0
                tx = dm[idx : idx + 1]
                idx += 1
                ty = dm[idx : idx + 1]
                idx += 1
                dflw = dm[idx : idx + self.nbins]
                idx += self.nbins
                dflh = dm[idx : idx + self.nbins]
                idx += self.nbins
                ang_logit = dm[idx : idx + 1]
                idx += 1
                obj_logit = dm[idx : idx + 1]
                idx += 1
                cls_logit = dm[idx : idx + self.num_classes]
                # compute grid
                key = (device, H, W)
                if key not in self._grid_cache:
                    yy, xx = torch.meshgrid(
                        torch.arange(H, device=device), torch.arange(W, device=device), indexing="ij"
                    )
                    self._grid_cache[key] = (xx, yy)
                gx, gy = self._grid_cache[key]
                # decode centre positions
                cx = ((torch.sigmoid(tx).squeeze(0) * 2.0 - 0.5) + gx) * stride
                cy = ((torch.sigmoid(ty).squeeze(0) * 2.0 - 0.5) + gy) * stride
                # decode width/height from DFL: expected log(w/stride)
                ev_w = self._ev_from_dfl(dflw)  # (1,H,W)
                ev_h = self._ev_from_dfl(dflh)
                w = torch.exp(ev_w.squeeze(0)) * stride
                h = torch.exp(ev_h.squeeze(0)) * stride
                # decode angle
                ang = (torch.sigmoid(ang_logit.squeeze(0)) - 0.5) * math.pi
                # canonicalise widths and heights (LE‑90)
                w, h, ang = self._le90(w, h, ang)
                # objectness and class probabilities
                obj = torch.sigmoid(obj_logit.squeeze(0))
                # cls probabilities
                cls_prob = torch.sigmoid(cls_logit)
                # keypoint offsets (u,v) ∈ [‑0.5,0.5]
                kpx = torch.sigmoid(km[0]) - 0.5
                kpy = torch.sigmoid(km[1]) - 0.5
                # compute bounding box corners for rotated NMS: convert to (cx,cy,w,h,ang)
                cx_flat = cx.reshape(-1)
                cy_flat = cy.reshape(-1)
                w_flat = w.reshape(-1)
                h_flat = h.reshape(-1)
                ang_flat = ang.reshape(-1)
                obj_flat = obj.reshape(-1)
                # classification: for multi‑class, treat each class separately
                if self.num_classes > 1:
                    cls_prob_flat = cls_prob.reshape(self.num_classes, -1)
                    # multiply with objectness
                    scores = (cls_prob_flat * obj_flat)
                    # apply score threshold
                    keep = scores > score_thr
                    # for each class
                    for cls_idx in range(self.num_classes):
                        mask = keep[cls_idx]
                        if mask.any():
                            cx_c = cx_flat[mask]
                            cy_c = cy_flat[mask]
                            w_c = w_flat[mask]
                            h_c = h_flat[mask]
                            ang_c = ang_flat[mask]
                            score_c = scores[cls_idx][mask]
                            # decode keypoint for these detections
                            u = kpx.reshape(-1)[mask]
                            v = kpy.reshape(-1)[mask]
                            # compute dx,dy in box coordinate system
                            dx = u * w_c
                            dy = v * h_c
                            # rotate to global
                            cos_a = torch.cos(ang_c)
                            sin_a = torch.sin(ang_c)
                            kx = cx_c + dx * cos_a - dy * sin_a
                            ky = cy_c + dx * sin_a + dy * cos_a
                            kpt = torch.stack([kx, ky], dim=1)
                            box = torch.stack([cx_c, cy_c, w_c, h_c, ang_c], dim=1)
                            boxes_l.append(box)
                            scores_l.append(score_c)
                            labels_l.append(torch.full_like(score_c, cls_idx))
                            kpts_l.append(kpt)
                else:
                    # single class
                    score = cls_prob.squeeze(0) * obj_flat
                    mask = score > score_thr
                    if mask.any():
                        cx_c = cx_flat[mask]
                        cy_c = cy_flat[mask]
                        w_c = w_flat[mask]
                        h_c = h_flat[mask]
                        ang_c = ang_flat[mask]
                        score_c = score[mask]
                        u = kpx.reshape(-1)[mask]
                        v = kpy.reshape(-1)[mask]
                        dx = u * w_c
                        dy = v * h_c
                        cos_a = torch.cos(ang_c)
                        sin_a = torch.sin(ang_c)
                        kx = cx_c + dx * cos_a - dy * sin_a
                        ky = cy_c + dx * sin_a + dy * cos_a
                        kpt = torch.stack([kx, ky], dim=1)
                        box = torch.stack([cx_c, cy_c, w_c, h_c, ang_c], dim=1)
                        boxes_l.append(box)
                        scores_l.append(score_c)
                        labels_l.append(torch.zeros_like(score_c, dtype=torch.int64))
                        kpts_l.append(kpt)
            # concatenate over levels
            if boxes_l:
                boxes_all = torch.cat(boxes_l, dim=0)
                scores_all = torch.cat(scores_l, dim=0)
                labels_all = torch.cat(labels_l, dim=0)
                kpts_all = torch.cat(kpts_l, dim=0)
                # apply NMS
                if use_nms and boxes_all.numel() > 0:
                    try:
                        from mmcv.ops import nms_rotated
                        # mmcv expects boxes in (cx,cy,w,h,angle_deg)
                        boxes_deg = boxes_all.clone()
                        boxes_deg[:, 4] = boxes_deg[:, 4] * 180.0 / math.pi
                        dets = torch.cat([boxes_deg, scores_all[:, None]], dim=1)
                        keep_inds = nms_rotated(dets, iou_thres, clockwise=False)[0]
                        if keep_inds.numel() > max_det:
                            keep_inds = keep_inds[:max_det]
                        boxes_all = boxes_all[keep_inds]
                        scores_all = scores_all[keep_inds]
                        labels_all = labels_all[keep_inds]
                        kpts_all = kpts_all[keep_inds]
                    except Exception:
                        # fallback to axis‑aligned NMS
                        from torchvision.ops import nms
                        # convert oriented boxes to axis‑aligned boxes for NMS
                        # approximate by bounding rectangle
                        x1 = boxes_all[:, 0] - boxes_all[:, 2] / 2.0
                        y1 = boxes_all[:, 1] - boxes_all[:, 3] / 2.0
                        x2 = boxes_all[:, 0] + boxes_all[:, 2] / 2.0
                        y2 = boxes_all[:, 1] + boxes_all[:, 3] / 2.0
                        aa_boxes = torch.stack([x1, y1, x2, y2], dim=1)
                        keep_inds = nms(aa_boxes, scores_all, iou_thres)
                        if keep_inds.numel() > max_det:
                            keep_inds = keep_inds[:max_det]
                        boxes_all = boxes_all[keep_inds]
                        scores_all = scores_all[keep_inds]
                        labels_all = labels_all[keep_inds]
                        kpts_all = kpts_all[keep_inds]
                results.append({
                    "boxes": boxes_all,
                    "scores": scores_all,
                    "labels": labels_all,
                    "keypoints": kpts_all,
                })
            else:
                results.append({
                    "boxes": torch.zeros((0, 5), device=device),
                    "scores": torch.zeros((0,), device=device),
                    "labels": torch.zeros((0,), dtype=torch.int64, device=device),
                    "keypoints": torch.zeros((0, 2), device=device),
                })
        return results


__all__ = ["OBBPoseHead"]
