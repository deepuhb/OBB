"""Detection heads."""

from .obbpose_head import OBBPoseHead  # noqa

__all__ = ["OBBPoseHead"]