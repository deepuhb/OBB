"""YOLOv11‑style model for oriented box and keypoint detection.

This module combines a CSPDarknet backbone, a PAN‑FPN neck and the
OBBPoseHead to create a complete detector.  The model exposes
``decode_obb_from_pyramids`` for inference, which converts raw
predictions into oriented boxes, scores, labels and keypoints using
rotated non‑maximum suppression.
"""

from __future__ import annotations

from typing import Tuple, List, Dict, Any
import torch
import torch.nn as nn

from .backbone.cspdarknet import CSPDarknet
from .neck.pan_fpn import PANFPN
from .heads.obbpose_head import OBBPoseHead


class YOLOOBBPOSE(nn.Module):
    """Full model for oriented bounding box and keypoint detection."""
    def __init__(
        self,
        num_classes: int = 1,
        base_channels: int = 64,
        base_depth: int = 3,
        reg_max: int = 8,
    ) -> None:
        super().__init__()
        # backbone
        self.backbone = CSPDarknet(base_channels=base_channels, base_depth=base_depth)
        # compute channels for neck
        c3 = base_channels * 8
        c4 = base_channels * 16
        c5 = base_channels * 32
        out_channels = base_channels * 4  # unify features to 4× base_channels
        self.neck = PANFPN((c3, c4, c5), out_channels)
        # head
        self.head = OBBPoseHead((out_channels, out_channels, out_channels), num_classes, reg_max=reg_max)

    def forward(self, x: torch.Tensor) -> Tuple[List[torch.Tensor], List[torch.Tensor]]:
        p3, p4, p5 = self.backbone(x)
        feats = self.neck((p3, p4, p5))
        det_maps, kpt_maps = self.head(feats)
        return det_maps, kpt_maps

    @torch.no_grad()
    def decode(
        self,
        x: torch.Tensor,
        **decode_kwargs: Any
    ) -> List[Dict[str, torch.Tensor]]:
        """Run inference and decode predictions.

        Args:
            x: input images tensor (B,3,H,W).
            decode_kwargs: forwarded to ``head.decode_obb_from_pyramids``.
        Returns:
            list of detection dicts per image.
        """
        det_maps, kpt_maps = self.forward(x)
        return self.head.decode_obb_from_pyramids(det_maps, kpt_maps, x, **decode_kwargs)


__all__ = ["YOLOOBBPOSE"]
