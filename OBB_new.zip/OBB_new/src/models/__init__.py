"""Model components for OBB_new."""

from .yolo_obb_pose import YOLOOBBPOSE  # noqa

__all__ = ["YOLOOBBPOSE"]