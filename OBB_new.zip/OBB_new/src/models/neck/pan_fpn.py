"""Path Aggregation Network (PAN‑FPN) for multi‑scale feature fusion.

The PAN‑FPN combines top‑down and bottom‑up pathways to aggregate
features from different depths of the backbone.  It takes three input
feature maps (P3, P4, P5) with decreasing resolutions and outputs a
list of three fused feature maps of uniform channel width.  The
implementation follows the design used in YOLOv8/v11 models.
"""

from __future__ import annotations

from typing import Tuple, List
import torch
import torch.nn as nn

from ..backbone.cspdarknet import ConvBNAct


class PANFPN(nn.Module):
    """Bidirectional feature pyramid network.

    Args:
        in_channels: tuple of three channel counts from the backbone (P3, P4, P5).
        out_channels: number of channels for all output feature maps.
    """

    def __init__(self, in_channels: Tuple[int, int, int], out_channels: int) -> None:
        super().__init__()
        c3, c4, c5 = in_channels
        c_out = out_channels
        # reduce channels to c_out with 1×1 convs
        self.reduce5 = ConvBNAct(c5, c_out, k=1, s=1, p=0)
        self.reduce4 = ConvBNAct(c4, c_out, k=1, s=1, p=0)
        self.reduce3 = ConvBNAct(c3, c_out, k=1, s=1, p=0)
        # top‑down convs after upsampling and addition
        self.conv_fpn4 = ConvBNAct(c_out, c_out, k=3)
        self.conv_fpn3 = ConvBNAct(c_out, c_out, k=3)
        # bottom‑up: downsample and fuse
        self.downsample3 = ConvBNAct(c_out, c_out, k=3, s=2)
        self.conv_pan4 = ConvBNAct(c_out, c_out, k=3)
        self.downsample4 = ConvBNAct(c_out, c_out, k=3, s=2)
        self.conv_pan5 = ConvBNAct(c_out, c_out, k=3)

    def forward(self, feats: Tuple[torch.Tensor, torch.Tensor, torch.Tensor]) -> List[torch.Tensor]:
        # feats: [P3, P4, P5]
        p3, p4, p5 = feats
        # reduce channels
        p5_r = self.reduce5(p5)
        p4_r = self.reduce4(p4)
        p3_r = self.reduce3(p3)
        # top‑down path: P5 -> P4 -> P3
        p5_up = nn.functional.interpolate(p5_r, size=p4_r.shape[-2:], mode="nearest")
        p4_f = self.conv_fpn4(p4_r + p5_up)
        p4_up = nn.functional.interpolate(p4_f, size=p3_r.shape[-2:], mode="nearest")
        p3_f = self.conv_fpn3(p3_r + p4_up)
        # bottom‑up path: P3_f -> P4_f -> P5_f
        p3_down = self.downsample3(p3_f)
        p4_f2 = self.conv_pan4(p4_f + p3_down)
        p4_down = self.downsample4(p4_f2)
        p5_f = self.conv_pan5(p5_r + p4_down)
        return [p3_f, p4_f2, p5_f]


__all__ = ["PANFPN"]
