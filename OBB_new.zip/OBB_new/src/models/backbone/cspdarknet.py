"""Cross‑Stage Partial (CSP) Darknet backbone.

This backbone implements a multi‑scale feature extractor following the
CSPDarknet architecture.  It consists of a stem convolution, followed
by a series of CSP stages that downsample the input and extract
increasingly abstract features.  The design is based on the Darknet
architecture used in YOLO models, with Cross‑Stage Partial networks
(CSP) to reduce parameter redundancy and improve gradient flow.  Each
stage outputs a feature map at a different scale; the last three
features (P3, P4, P5) are typically used for detection heads.
"""

from __future__ import annotations

from typing import Tuple, List

import torch
import torch.nn as nn


class ConvBNAct(nn.Module):
    """Convolution followed by BatchNorm and SiLU activation."""
    def __init__(self, c_in: int, c_out: int, k: int = 1, s: int = 1, p: Optional[int] = None) -> None:
        super().__init__()
        if p is None:
            p = k // 2
        self.conv = nn.Conv2d(c_in, c_out, kernel_size=k, stride=s, padding=p, bias=False)
        self.bn = nn.BatchNorm2d(c_out)
        self.act = nn.SiLU()  # avoid in‑place to prevent autograd issues

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.act(self.bn(self.conv(x)))


class Bottleneck(nn.Module):
    """Standard bottleneck with optional residual connection."""
    def __init__(self, c_in: int, c_out: int, shortcut: bool = True, expansion: float = 0.5) -> None:
        super().__init__()
        hidden = int(c_out * expansion)
        self.conv1 = ConvBNAct(c_in, hidden, k=1)
        self.conv2 = ConvBNAct(hidden, c_out, k=3)
        self.use_res = shortcut and c_in == c_out

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.conv2(self.conv1(x))
        if self.use_res:
            y = y + x
        return y


class C3(nn.Module):
    """Cross‑Stage Partial module with a sequence of Bottlenecks.

    Splits input into two branches: one processed by ``n`` bottleneck blocks
    and the other passed through unchanged.  Concatenates the results and
    applies a final 1×1 convolution to fuse features.
    """
    def __init__(self, c_in: int, c_out: int, n: int = 1, shortcut: bool = True, expansion: float = 0.5) -> None:
        super().__init__()
        hidden = int(c_out * expansion)
        self.conv1 = ConvBNAct(c_in, hidden, k=1)
        self.conv2 = ConvBNAct(c_in, hidden, k=1)
        self.conv3 = ConvBNAct(2 * hidden, c_out, k=1)
        self.m = nn.Sequential(*[Bottleneck(hidden, hidden, shortcut, expansion=1.0) for _ in range(n)])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y1 = self.m(self.conv1(x))
        y2 = self.conv2(x)
        return self.conv3(torch.cat([y1, y2], dim=1))


class CSPDarknet(nn.Module):
    """CSPDarknet backbone producing feature maps at three scales.

    Args:
        base_channels: number of base channels (default 64).  The number of
            channels in each stage scales proportionally.
        base_depth: number of bottleneck layers in each CSP stage (default 3).
    """

    def __init__(self, base_channels: int = 64, base_depth: int = 3) -> None:
        super().__init__()
        c = base_channels
        d = base_depth
        # stem
        self.stem = ConvBNAct(3, c, k=3, s=1)
        # Stage 1: downsample to 1/2 and apply C3
        self.stage1 = nn.Sequential(
            ConvBNAct(c, c * 2, k=3, s=2),
            C3(c * 2, c * 2, n=d, shortcut=True, expansion=0.5),
        )
        # Stage 2: downsample to 1/4
        self.stage2 = nn.Sequential(
            ConvBNAct(c * 2, c * 4, k=3, s=2),
            C3(c * 4, c * 4, n=d * 3, shortcut=True, expansion=0.5),
        )
        # Stage 3: downsample to 1/8
        self.stage3 = nn.Sequential(
            ConvBNAct(c * 4, c * 8, k=3, s=2),
            C3(c * 8, c * 8, n=d * 3, shortcut=True, expansion=0.5),
        )
        # Stage 4: downsample to 1/16
        self.stage4 = nn.Sequential(
            ConvBNAct(c * 8, c * 16, k=3, s=2),
            C3(c * 16, c * 16, n=d * 3, shortcut=True, expansion=0.5),
        )
        # Stage 5: downsample to 1/32
        self.stage5 = nn.Sequential(
            ConvBNAct(c * 16, c * 32, k=3, s=2),
            C3(c * 32, c * 32, n=d, shortcut=True, expansion=0.5),
        )

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        # x: (B,3,H,W)
        x = self.stem(x)
        x = self.stage1(x)
        x = self.stage2(x)
        x3 = self.stage3(x)
        x4 = self.stage4(x3)
        x5 = self.stage5(x4)
        return x3, x4, x5


__all__ = ["CSPDarknet"]
