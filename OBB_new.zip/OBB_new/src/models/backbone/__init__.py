"""Backbone architectures."""

from .cspdarknet import CSPDarknet  # noqa

__all__ = ["CSPDarknet"]