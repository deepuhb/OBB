"""Training utilities for the OBB_new model.

This module defines a training loop supporting multi‑GPU training via
`torch.nn.parallel.DistributedDataParallel` (DDP).  It accepts a model,
criterion, optimisers and dataloaders, and handles gradient
accumulation, mixed precision and periodic evaluation.
"""

from __future__ import annotations

from typing import Any, Tuple, Dict, Optional
import math
import time

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, DistributedSampler

from ..models.yolo_obb_pose import YOLOOBBPOSE
from ..models.losses.obb_pose_loss import OBBCriterion
from .evaluate import evaluate


def train_one_epoch(
    model: nn.Module,
    criterion: OBBCriterion,
    dataloader: DataLoader,
    optimiser: torch.optim.Optimizer,
    device: torch.device,
    scaler: Optional[torch.cuda.amp.GradScaler] = None,
    max_norm: Optional[float] = None,
) -> Dict[str, float]:
    """Run a single training epoch.

    Returns a dictionary of average loss components.
    """
    model.train()
    logs_accum: Dict[str, float] = {
        "loss": 0.0,
        "l_box": 0.0,
        "l_obj": 0.0,
        "l_cls": 0.0,
        "l_ang": 0.0,
        "l_kpt": 0.0,
        "l_iou": 0.0,
    }
    num_batches = len(dataloader)
    for images, targets in dataloader:
        images = images.to(device)
        # move targets to device
        targets_dev = []
        for t in targets:
            td: Dict[str, torch.Tensor] = {}
            for k, v in t.items():
                td[k] = v.to(device)
            targets_dev.append(td)
        optimiser.zero_grad(set_to_none=True)
        # use automatic mixed precision when scaler is provided
        if scaler is not None:
            # infer device type for autocast (cuda or cpu)
            if device.type == "cuda":
                context = torch.amp.autocast(device_type="cuda", dtype=torch.float16, enabled=True)
            else:
                context = torch.amp.autocast(device_type="cpu", dtype=torch.bfloat16, enabled=True)
        else:
            # dummy context manager
            class DummyCtx:
                def __enter__(self):
                    return None
                def __exit__(self, exc_type, exc, tb):
                    return False
            context = DummyCtx()
        with context:
            det_maps, kpt_maps = model(images)
            total_loss, loss_dict = criterion(det_maps, kpt_maps, targets_dev)
        if scaler is not None:
            scaler.scale(total_loss).backward()
            if max_norm is not None:
                scaler.unscale_(optimiser)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)
            scaler.step(optimiser)
            scaler.update()
        else:
            total_loss.backward()
            if max_norm is not None:
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)
            optimiser.step()
        # accumulate losses
        logs_accum["loss"] += total_loss.item()
        for k, v in loss_dict.items():
            logs_accum[k] += float(v.item())
    # average
    for k in logs_accum:
        logs_accum[k] /= num_batches
    return logs_accum


def train(
    model: YOLOOBBPOSE,
    criterion: OBBCriterion,
    train_loader: DataLoader,
    val_loader: Optional[DataLoader],
    optimiser: torch.optim.Optimizer,
    device: torch.device,
    epochs: int = 100,
    eval_interval: int = 5,
    scaler: Optional[torch.cuda.amp.GradScaler] = None,
    max_norm: Optional[float] = None,
) -> None:
    """Train the model for a number of epochs with optional evaluation."""
    # handle distributed sampler epoch setting
    sampler: Optional[DistributedSampler] = train_loader.sampler if isinstance(train_loader.sampler, DistributedSampler) else None
    for epoch in range(1, epochs + 1):
        if sampler is not None:
            sampler.set_epoch(epoch)
        t0 = time.time()
        logs = train_one_epoch(model, criterion, train_loader, optimiser, device, scaler=scaler, max_norm=max_norm)
        t1 = time.time()
        if torch.distributed.is_initialized():
            # reduce losses across all ranks
            for k in logs:
                v = torch.tensor(logs[k], device=device)
                torch.distributed.all_reduce(v, op=torch.distributed.ReduceOp.SUM)
                logs[k] = v.item() / torch.distributed.get_world_size()
        # print training stats on rank 0
        if not torch.distributed.is_initialized() or torch.distributed.get_rank() == 0:
            lr = optimiser.param_groups[0]["lr"]
            print(f"Epoch {epoch}: loss={logs['loss']:.4f} lr={lr:.5f} time={t1 - t0:.1f}s")
        # evaluation
        if val_loader is not None and (epoch % eval_interval == 0 or epoch == epochs):
            if not torch.distributed.is_initialized() or torch.distributed.get_rank() == 0:
                ap = evaluate(model, val_loader, iou_threshold=0.5, score_threshold=0.01, max_det=300, device=device)
                print(f"Eval mAP50={ap['mAP']:.4f}")


__all__ = ["train", "train_one_epoch"]
