"""Evaluation utilities for oriented box detection.

The evaluator computes mAP@0.5 for oriented boxes by matching
predictions to ground‑truth annotations using rotated IoU.  The IoU is
calculated via mmcv's ``box_iou_rotated`` when available and falls back
to an axis‑aligned approximation otherwise.  AP is computed for each
class separately and averaged to obtain mAP.
"""

from __future__ import annotations

from typing import List, Dict, Tuple, Optional
import torch
import numpy as np

try:
    from mmcv.ops import box_iou_rotated as mmcv_box_iou_rotated  # type: ignore
except Exception:
    mmcv_box_iou_rotated = None
from torchvision.ops import box_iou as tv_box_iou


def _compute_iou_rotated(pred_boxes: torch.Tensor, gt_boxes: torch.Tensor) -> torch.Tensor:
    """Compute IoU between oriented boxes using mmcv.  If mmcv is not
    available, approximate by axis‑aligned IoU.

    Args:
        pred_boxes: (M,5) [cx,cy,w,h,theta] in pixels, theta in radians.
        gt_boxes: (N,5) same as above.
    Returns:
        ious: (M,N) tensor of IoU values.
    """
    if pred_boxes.numel() == 0 or gt_boxes.numel() == 0:
        return torch.zeros((pred_boxes.shape[0], gt_boxes.shape[0]), device=pred_boxes.device)
    if mmcv_box_iou_rotated is not None:
        # convert angles to degrees
        pb = pred_boxes.clone()
        gb = gt_boxes.clone()
        pb[:, 4] = pb[:, 4] * 180.0 / np.pi
        gb[:, 4] = gb[:, 4] * 180.0 / np.pi
        return mmcv_box_iou_rotated(pb, gb)
    else:
        # approximate by axis aligned IoU from bounding rectangles
        x1p = pred_boxes[:, 0] - pred_boxes[:, 2] / 2.0
        y1p = pred_boxes[:, 1] - pred_boxes[:, 3] / 2.0
        x2p = pred_boxes[:, 0] + pred_boxes[:, 2] / 2.0
        y2p = pred_boxes[:, 1] + pred_boxes[:, 3] / 2.0
        x1g = gt_boxes[:, 0] - gt_boxes[:, 2] / 2.0
        y1g = gt_boxes[:, 1] - gt_boxes[:, 3] / 2.0
        x2g = gt_boxes[:, 0] + gt_boxes[:, 2] / 2.0
        y2g = gt_boxes[:, 1] + gt_boxes[:, 3] / 2.0
        pb_aa = torch.stack([x1p, y1p, x2p, y2p], dim=1)
        gb_aa = torch.stack([x1g, y1g, x2g, y2g], dim=1)
        return tv_box_iou(pb_aa, gb_aa)


def evaluate(
    model: torch.nn.Module,
    dataloader: torch.utils.data.DataLoader,
    iou_threshold: float = 0.5,
    score_threshold: float = 0.01,
    max_det: int = 300,
    device: Optional[torch.device] = None,
) -> Dict[str, float]:
    """Compute mAP@iou_threshold for the provided dataset.

    Args:
        model: trained model in eval mode.
        dataloader: DataLoader yielding (images, targets).
        iou_threshold: IoU threshold to consider a detection a true positive.
        score_threshold: minimum score to keep detections.
        max_det: maximum detections per image.
        device: device on which to perform inference.
    Returns:
        dict with mAP and per‑class AP.
    """
    model.eval()
    device = device or next(model.parameters()).device
    # accumulate predictions and ground truths per class
    all_scores: Dict[int, List[float]] = {}
    all_matches: Dict[int, List[int]] = {}
    gt_count: Dict[int, int] = {}
    # iterate dataset
    with torch.no_grad():
        for images, targets in dataloader:
            images = images.to(device)
            preds = model.decode(images, score_thr=score_threshold, iou_thres=iou_threshold, max_det=max_det, use_nms=True)
            for p, tgt in zip(preds, targets):
                gt_boxes = tgt.get("boxes").to(device)
                gt_labels = tgt.get("labels").to(device)
                # update gt_count per class
                for cls_id in gt_labels.unique():
                    gt_count[int(cls_id.item())] = gt_count.get(int(cls_id.item()), 0) + (gt_labels == cls_id).sum().item()
                pred_boxes = p["boxes"].to(device)
                pred_scores = p["scores"].to(device)
                pred_labels = p["labels"].to(device)
                if pred_boxes.numel() == 0:
                    continue
                # compute IoU between predictions and GTs
                ious = _compute_iou_rotated(pred_boxes, gt_boxes)
                # for each prediction sorted by score
                order = torch.argsort(pred_scores, descending=True)
                pred_boxes = pred_boxes[order]
                pred_scores = pred_scores[order]
                pred_labels = pred_labels[order]
                ious = ious[order]
                # track assignments per class
                assigned = torch.zeros(len(gt_boxes), dtype=torch.bool, device=device)
                for pb, ps, pl, iou_row in zip(pred_boxes, pred_scores, pred_labels, ious):
                    cls_id = int(pl.item())
                    # ensure lists exist
                    all_scores.setdefault(cls_id, []).append(float(ps.item()))
                    # find best matching GT for this class
                    match_idx = -1
                    best_iou = 0.0
                    for j, (gt_iou, gt_label) in enumerate(zip(iou_row, gt_labels)):
                        if assigned[j]:
                            continue
                        if int(gt_label.item()) != cls_id:
                            continue
                        if gt_iou > best_iou:
                            best_iou = float(gt_iou)
                            match_idx = j
                    # record match
                    if best_iou >= iou_threshold and match_idx >= 0:
                        assigned[match_idx] = True
                        all_matches.setdefault(cls_id, []).append(1)
                    else:
                        all_matches.setdefault(cls_id, []).append(0)
    # compute AP per class
    ap_per_cls: Dict[int, float] = {}
    for cls_id in sorted(set(list(all_scores.keys()) + list(gt_count.keys()))):
        scores = np.array(all_scores.get(cls_id, []))
        matches = np.array(all_matches.get(cls_id, []))
        npos = gt_count.get(cls_id, 0)
        if npos == 0:
            ap_per_cls[cls_id] = 0.0
            continue
        if len(scores) == 0:
            ap_per_cls[cls_id] = 0.0
            continue
        # sort scores descending (they are already sorted)
        tp = matches
        fp = 1 - matches
        # cumulative sums
        tp_cum = np.cumsum(tp)
        fp_cum = np.cumsum(fp)
        recall = tp_cum / (npos + 1e-12)
        precision = tp_cum / (tp_cum + fp_cum + 1e-12)
        # compute AP by numeric integration
        # ensure (0,1) start and (1,0) end
        mrec = np.concatenate(([0.0], recall, [1.0]))
        mpre = np.concatenate(([1.0], precision, [0.0]))
        # make precision monotonically decreasing
        for i in range(mpre.size - 1, 0, -1):
            mpre[i - 1] = max(mpre[i - 1], mpre[i])
        # compute area under PR curve
        idx = np.where(mrec[1:] != mrec[:-1])[0]
        ap = float(np.sum((mrec[idx + 1] - mrec[idx]) * mpre[idx + 1]))
        ap_per_cls[cls_id] = ap
    # compute mAP
    mAP = float(np.mean(list(ap_per_cls.values()))) if ap_per_cls else 0.0
    ap_per_cls["mAP"] = mAP
    return ap_per_cls


__all__ = ["evaluate"]
