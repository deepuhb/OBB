"""Evaluation utilities for oriented box detection.

This module implements a simple evaluation routine computing
mean Average Precision (mAP@0.5) for oriented boxes and keypoints.
The mAP is computed across all classes in the dataset.  For each
image the model’s predictions are decoded, filtered by confidence
threshold and NMS, and then matched to ground‑truth boxes using
IoU computed via ``mmcv.ops.box_iou_rotated``.  Detections with
IoU ≥ 0.5 are counted as true positives; the rest are false
positives.  The average precision is computed per class and then
averaged.

This evaluator is intentionally simple and not intended to match
official COCO metrics; however, it provides a useful measure of
progress during development and training.
"""

from __future__ import annotations

from typing import List, Dict, Tuple
import torch
from torch.utils.data import DataLoader

try:
    from mmcv.ops import box_iou_rotated as mmcv_box_iou_rotated  # type: ignore
except Exception:
    mmcv_box_iou_rotated = None


def evaluate_map(
    model: torch.nn.Module,
    dataloader: DataLoader,
    num_classes: int,
    device: torch.device,
    iou_thr: float = 0.5,
    score_thr: float = 0.01,
    max_det: int = 300,
) -> float:
    """Evaluate mAP@0.5 across the dataset.

    Args:
        model: model in evaluation mode.
        dataloader: DataLoader providing evaluation samples.
        num_classes: number of classes.
        device: torch device on which to run evaluation.
        iou_thr: IoU threshold to consider a detection correct.
        score_thr: score threshold passed to decoder.
        max_det: maximum detections per image.
    Returns:
        mAP@0.5 as a float.
    """
    model.eval()
    # lists per class
    all_scores: List[torch.Tensor] = [torch.tensor([], device=device) for _ in range(num_classes)]
    all_tp: List[torch.Tensor] = [torch.tensor([], device=device) for _ in range(num_classes)]
    npos: List[int] = [0 for _ in range(num_classes)]
    with torch.no_grad():
        for imgs, targets in dataloader:
            imgs = imgs.to(device, non_blocking=True)
            det_maps, kpt_maps = model(imgs)
            results = model.decode(det_maps, kpt_maps, imgs, score_thr=score_thr, iou_thres=iou_thr, max_det=max_det)
            # iterate images
            for res, tgt in zip(results, targets):
                gt_boxes = tgt.get("boxes")  # (N,5)
                gt_labels = tgt.get("labels")
                if gt_boxes is None or gt_boxes.numel() == 0:
                    # no gt: all predictions are false positives
                    if res["boxes"].numel() > 0:
                        for cls in range(num_classes):
                            cls_mask = (res["labels"] == cls)
                            scores = res["scores"][cls_mask]
                            all_scores[cls] = torch.cat([all_scores[cls], scores])
                            all_tp[cls] = torch.cat([all_tp[cls], torch.zeros_like(scores)])
                    continue
                # convert gt boxes to degrees for IoU calc
                if mmcv_box_iou_rotated is None:
                    raise RuntimeError("mmcv is required for evaluation")
                gt_boxes_deg = gt_boxes.clone().to(device)
                gt_boxes_deg[:, 4] = gt_boxes_deg[:, 4] * 180.0 / torch.pi
                # count positives per class
                for cls in range(num_classes):
                    npos[cls] += int((gt_labels == cls).sum().item())
                # prepare predicted results
                if res["boxes"].numel() > 0:
                    pred_boxes = res["boxes"].to(device)
                    pred_boxes_deg = pred_boxes.clone()
                    pred_boxes_deg[:, 4] = pred_boxes_deg[:, 4] * 180.0 / torch.pi
                    pred_scores = res["scores"].to(device)
                    pred_labels = res["labels"].to(device)
                    # sort by descending score
                    order = torch.argsort(pred_scores, descending=True)
                    pred_boxes_deg = pred_boxes_deg[order]
                    pred_boxes = pred_boxes[order]
                    pred_scores = pred_scores[order]
                    pred_labels = pred_labels[order]
                    # mark assigned gt
                    assigned = torch.zeros(gt_boxes.shape[0], dtype=torch.bool, device=device)
                    # compute IoU matrix between preds and gt boxes
                    ious = mmcv_box_iou_rotated(pred_boxes_deg, gt_boxes_deg)  # (P,N)
                    for i, (pbox, score, label) in enumerate(zip(pred_boxes, pred_scores, pred_labels)):
                        # store score
                        all_scores[label] = torch.cat([all_scores[label], score.unsqueeze(0)])
                        # find best match
                        ious_i = ious[i]
                        # consider only gt of the same class
                        match_gt = (gt_labels == label)
                        if match_gt.any():
                            iou_class = ious_i[match_gt]
                            if iou_class.numel() > 0:
                                max_iou, idx_rel = iou_class.max(dim=0)
                                if max_iou >= iou_thr:
                                    # find absolute index of the gt
                                    idx = torch.nonzero(match_gt)[idx_rel].item()
                                    if not assigned[idx]:
                                        # true positive
                                        all_tp[label] = torch.cat([all_tp[label], torch.ones(1, device=device)])
                                        assigned[idx] = True
                                        continue
                        # false positive
                        all_tp[label] = torch.cat([all_tp[label], torch.zeros(1, device=device)])
                else:
                    # no predictions: nothing to update
                    pass
        # compute AP per class
        ap = []
        for cls in range(num_classes):
            scores = all_scores[cls]
            tps = all_tp[cls]
            if scores.numel() == 0:
                ap.append(0.0)
                continue
            # sort by score descending
            order = torch.argsort(scores, descending=True)
            tps = tps[order]
            fps = 1.0 - tps
            # cumulative sums
            tp_cum = torch.cumsum(tps, dim=0)
            fp_cum = torch.cumsum(fps, dim=0)
            recalls = tp_cum / max(npos[cls], 1)
            precisions = tp_cum / (tp_cum + fp_cum + 1e-12)
            # compute AP using trapezoidal rule
            ap_cls = 0.0
            if precisions.numel() > 0:
                for i in range(precisions.numel() - 1):
                    ap_cls += (recalls[i + 1] - recalls[i]) * max(precisions[i + 1], precisions[i])
            ap.append(ap_cls)
        mAP = float(sum(ap) / max(num_classes, 1))
    return mAP


__all__ = ["evaluate_map"]
