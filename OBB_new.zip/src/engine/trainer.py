"""Training utilities for the OBB_new model.

This module provides functions to train the model for one epoch and
optionally evaluate on a validation set.  It supports mixed precision
training via ``torch.amp`` and distributed training via
``torch.nn.parallel.DistributedDataParallel``.  The trainer does not
instantiate the model or criterion; those are passed in by the caller.
"""

from __future__ import annotations

from typing import List, Dict, Tuple, Optional
import torch
from torch.utils.data import DataLoader
from torch.cuda.amp import GradScaler, autocast

from .evaluate import evaluate_map


def train_one_epoch(
    model: torch.nn.Module,
    criterion: torch.nn.Module,
    dataloader: DataLoader,
    optimizer: torch.optim.Optimizer,
    scaler: GradScaler,
    device: torch.device,
    amp: bool = False,
) -> float:
    """Train the model for a single epoch.

    Args:
        model: the model to train.
        criterion: loss function.
        dataloader: DataLoader for training data.
        optimizer: optimizer.
        scaler: gradient scaler for mixed precision.
        device: torch device.
        amp: whether to use mixed precision.
    Returns:
        Average loss over the epoch.
    """
    model.train()
    running_loss = 0.0
    for imgs, targets in dataloader:
        imgs = imgs.to(device, non_blocking=True)
        # move targets to device
        tgt_dev: List[Dict[str, torch.Tensor]] = []
        for t in targets:
            t_dev: Dict[str, torch.Tensor] = {}
            for k, v in t.items():
                if isinstance(v, torch.Tensor):
                    t_dev[k] = v.to(device, non_blocking=True)
                else:
                    t_dev[k] = v
            tgt_dev.append(t_dev)
        optimizer.zero_grad()
        with autocast(enabled=amp):
            det_maps, kpt_maps = model(imgs)
            loss, _logs = criterion(det_maps, kpt_maps, tgt_dev)
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        running_loss += loss.item()
    return running_loss / max(len(dataloader), 1)


def train_model(
    model: torch.nn.Module,
    criterion: torch.nn.Module,
    train_loader: DataLoader,
    val_loader: Optional[DataLoader],
    optimizer: torch.optim.Optimizer,
    scaler: GradScaler,
    device: torch.device,
    epochs: int = 50,
    amp: bool = False,
    eval_interval: int = 1,
    num_classes: int = 1,
    rank: int = 0,
    world_size: int = 1,
) -> None:
    """Train the model for multiple epochs with optional evaluation.

    Args:
        model: model to train (may be DDP wrapped).
        criterion: loss criterion.
        train_loader: DataLoader for training set.
        val_loader: optional DataLoader for validation set.
        optimizer: optimizer.
        scaler: gradient scaler for mixed precision.
        device: torch device.
        epochs: number of epochs to train.
        amp: whether to use mixed precision.
        eval_interval: run evaluation every this many epochs (on rank 0).
        num_classes: number of classes for evaluation.
        rank: process rank in distributed training.
        world_size: total number of processes.
    """
    for epoch in range(epochs):
        # set epoch for distributed sampler
        if hasattr(train_loader.sampler, "set_epoch"):
            train_loader.sampler.set_epoch(epoch)
        loss = train_one_epoch(model, criterion, train_loader, optimizer, scaler, device, amp)
        if rank == 0:
            print(f"Epoch {epoch + 1}/{epochs} | loss={loss:.4f}")
        # evaluation
        if val_loader is not None and (epoch + 1) % eval_interval == 0:
            if rank == 0:
                mAP = evaluate_map(model.module if hasattr(model, "module") else model, val_loader, num_classes, device)
                print(f"Validation mAP@0.5: {mAP:.4f}")


__all__ = ["train_one_epoch", "train_model"]
