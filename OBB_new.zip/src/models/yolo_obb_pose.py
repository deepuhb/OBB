"""Model wrapper combining backbone, neck and head for OBB detection.

This module defines the high‑level model class that encapsulates the
CSPDarknet backbone, PAN‑FPN neck and OBBPoseHead.  It exposes a
``forward`` method returning detection and keypoint feature maps and a
``decode`` method that uses the head’s decoder to turn predictions into
boxes, scores, labels and keypoints.
"""

from __future__ import annotations

from typing import List, Dict, Tuple
import torch
import torch.nn as nn

from .backbone.cspdarknet import CSPDarknet
from .neck.pan_fpn import PANFPN
from .heads.obbpose_head import OBBPoseHead


class YOLOOBBPOSE(nn.Module):
    """YOLO‑style model for oriented box and keypoint detection."""

    def __init__(
        self,
        num_classes: int,
        reg_max: int = 8,
        base_channels: int = 64,
        base_depth: int = 3,
    ) -> None:
        super().__init__()
        # backbone
        self.backbone = CSPDarknet(base_channels, base_depth)
        # compute channels for neck input
        c_out3 = base_channels * 8
        c_out4 = base_channels * 16
        c_out5 = base_channels * 32
        # neck: unify to c_out3
        self.neck = PANFPN((c_out3, c_out4, c_out5), c_out3)
        # head: uses c_out3 for all levels
        self.head = OBBPoseHead((c_out3, c_out3, c_out3), num_classes, reg_max=reg_max)

    def forward(self, x: torch.Tensor) -> Tuple[List[torch.Tensor], List[torch.Tensor]]:
        # x: (B,3,H,W)
        feats = self.backbone(x)  # returns P3,P4,P5
        neck_out = self.neck(feats)  # list of fused features [P3,P4,P5]
        det_maps, kpt_maps = self.head(neck_out)
        return det_maps, kpt_maps

    @torch.no_grad()
    def decode(self, det_maps: List[torch.Tensor], kpt_maps: List[torch.Tensor], imgs: torch.Tensor, **kwargs) -> List[Dict[str, torch.Tensor]]:
        """Decode raw outputs into oriented boxes, scores, labels and keypoints."""
        return self.head.decode_obb_from_pyramids(det_maps, kpt_maps, imgs, **kwargs)


__all__ = ["YOLOOBBPOSE"]
