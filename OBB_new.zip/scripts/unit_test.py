"""Basic unit test for the OBB_new detection pipeline.

This script loads a small dataset and runs a forward and decode pass
through the model to verify that the entire pipeline executes
successfully.  It is intended as a sanity check and does not train
the model.  The user must provide a dataset root containing at least
one image and its label in YOLO quadrilateral format.
"""

from __future__ import annotations

import argparse
import torch
from torch.utils.data import DataLoader

from src.data.datasets import YoloObbKptDataset
from src.data.collate import collate_obbdet
from src.models.yolo_obb_pose import YOLOOBBPOSE


def parse_args():
    parser = argparse.ArgumentParser(description="Unit test for OBB_new")
    parser.add_argument("--data", type=str, required=True, help="Dataset root for testing")
    parser.add_argument("--num_classes", type=int, required=True, help="Number of classes")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    dataset = YoloObbKptDataset(root=args.data, split="train", img_size=640, mosaic=False)
    dataloader = DataLoader(dataset, batch_size=1, shuffle=False, collate_fn=collate_obbdet)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = YOLOOBBPOSE(num_classes=args.num_classes, reg_max=8).to(device)
    model.eval()
    with torch.no_grad():
        for imgs, targets in dataloader:
            imgs = imgs.to(device)
            det_maps, kpt_maps = model(imgs)
            results = model.decode(det_maps, kpt_maps, imgs, score_thr=0.1, iou_thres=0.5)
            print("Decoded detections:")
            for res in results:
                print({k: v.cpu().numpy() for k, v in res.items()})
            break


if __name__ == "__main__":
    main()
