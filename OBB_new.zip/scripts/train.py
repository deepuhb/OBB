"""Command‑line training entry for OBB_new.

This script trains the YOLO‑v11‑style oriented box and keypoint detector
on a custom dataset.  It supports multi‑GPU training via
``torchrun``.  Example usage:

```bash
PYTHONPATH=. torchrun --standalone --nproc_per_node=4 \
    OBB_new/scripts/train.py \
    --data /path/to/dataset \
    --num_classes 2 \
    --epochs 300 \
    --batch 32 \
    --img_size 640
```

The dataset root must contain ``images/``, ``labels/`` and text files
``train.txt`` and ``val.txt`` listing the images for each split.  See
``README.md`` for details.
"""

from __future__ import annotations

import argparse
import os
import torch
import torch.distributed as dist
from torch.utils.data import DataLoader, DistributedSampler

from src.data.datasets import YoloObbKptDataset
from src.data.collate import collate_obbdet
from src.models.yolo_obb_pose import YOLOOBBPOSE
from src.models.losses.obb_pose_loss import OBBCriterion
from src.engine.trainer import train_model


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train OBB_new model")
    parser.add_argument("--data", type=str, required=True, help="Dataset root directory")
    parser.add_argument("--epochs", type=int, default=50, help="Number of training epochs")
    parser.add_argument("--batch", type=int, default=16, help="Batch size per GPU")
    parser.add_argument("--lr", type=float, default=0.01, help="Learning rate")
    parser.add_argument("--num_classes", type=int, required=True, help="Number of object classes")
    parser.add_argument("--reg_max", type=int, default=8, help="Max bin index for DFL")
    parser.add_argument("--img_size", type=int, default=640, help="Image size (square)")
    parser.add_argument("--workers", type=int, default=4, help="Number of DataLoader workers")
    parser.add_argument("--no_augment", action="store_true", help="Disable mosaic and colour augmentation")
    parser.add_argument("--amp", action="store_true", help="Enable mixed precision training")
    parser.add_argument("--neighbor_range", type=int, default=1, help="Neighbourhood radius for positive cells")
    parser.add_argument("--lambda_iou", type=float, default=0.0, help="Weight for IoU penalty")
    parser.add_argument("--eval_interval", type=int, default=1, help="Evaluate every N epochs on validation set")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    # determine distributed training
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    distributed = world_size > 1
    device = torch.device("cuda", local_rank) if torch.cuda.is_available() else torch.device("cpu")
    if distributed:
        dist.init_process_group(backend="nccl" if torch.cuda.is_available() else "gloo", init_method="env://")
        torch.cuda.set_device(local_rank)
    # dataset and dataloader
    train_dataset = YoloObbKptDataset(
        root=args.data,
        split="train",
        img_size=args.img_size,
        mosaic=not args.no_augment,
    )
    val_dataset = YoloObbKptDataset(
        root=args.data,
        split="val",
        img_size=args.img_size,
        mosaic=False,
    )
    train_sampler = DistributedSampler(train_dataset) if distributed else None
    val_sampler = DistributedSampler(val_dataset, shuffle=False) if distributed else None
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch,
        sampler=train_sampler,
        shuffle=(train_sampler is None),
        num_workers=args.workers,
        collate_fn=collate_obbdet,
        pin_memory=True,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch,
        sampler=val_sampler,
        shuffle=False,
        num_workers=args.workers,
        collate_fn=collate_obbdet,
        pin_memory=True,
    )
    # model
    model = YOLOOBBPOSE(
        num_classes=args.num_classes,
        reg_max=args.reg_max,
        base_channels=64,
        base_depth=3,
    )
    model.to(device)
    # DDP wrap
    if distributed:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[local_rank], find_unused_parameters=True)
    # loss
    criterion = OBBCriterion(
        num_classes=args.num_classes,
        strides=(8, 16, 32),
        level_boundaries=(32.0, 64.0),
        neighbor_range=args.neighbor_range,
        lambda_box=5.0,
        lambda_obj=1.0,
        lambda_cls=0.5,
        lambda_ang=0.5,
        lambda_kpt=2.0,
        lambda_iou=args.lambda_iou,
    )
    # optimizer
    optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.937, weight_decay=5e-4)
    scaler = torch.cuda.amp.GradScaler(enabled=args.amp)
    # train
    train_model(
        model,
        criterion,
        train_loader,
        val_loader,
        optimizer,
        scaler,
        device,
        epochs=args.epochs,
        amp=args.amp,
        eval_interval=args.eval_interval,
        num_classes=args.num_classes,
        rank=local_rank,
        world_size=world_size,
    )
    # cleanup
    if distributed:
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
